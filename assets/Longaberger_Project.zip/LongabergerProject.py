# Dev Name: Clay Gleason
# Date : 10/15/2024
# Program Title: Longaberger
# Program Purpose: Calculate Basket Sales
# Python Ver. 3.11
from datetime import date

# string
oDate = ""
oPgCtr = ""
oBasketPrice = ""
oQuantity = ""
oSubtotal = ""
oDiscount = ""
oTotal = ""
oGtCustomerCtr = ""
oGtQuantity = ""
oGtSubtotal = ""
oGtDiscount = ""
oGtTotal = ""

iBasketPrice = ""
iDiscount = ""
iQuantity = ""
iCustomerName = ""
iBasketType = ""
iAccessories = ""
iDate = ""


# calculated fields
cSubtotal = 0
cTotal = 0
cGtSubtotal = 0
cGtDiscount = 0
cGtTotal = 0

# Accumulated fields
cPgCtr = 0
cGtCustomerCtr = 0
cGtQuantity = 0
cLineCtr = 0

# Major Fields
cMjSubtotal = 0
cMjDiscount = 0
cMjTotal = 0

# Minor Fields
cMnSubtotal = 0
cMnDiscount = 0
cMnTotal = 0

# output for major and minor break
oMjSubtotal = 0
oMjDiscount = 0
oMjTotal = 0

oMnSubtotal = 0
oMnDiscount = 0
oMnTotal = 0

hold_date = ""
hold_basket_type = ""

moreRecs = "Yes"

current_date = ""

def main():
    file_output, file_input = init()
    while moreRecs == "Yes":
        calcs()
        output(file_output)
        read(file_input)
    grandtotals(file_output)
    closing(file_output, file_input)

def init():
    global current_date
    file_input = open("inputdata.txt", "r")
    file_output = open("outputdata.txt", "a")

    current_date = date.today()

    headings(file_output)
    read(file_input)

    return file_output, file_input

def headings(file_output):
    global cLineCtr, cPgCtr, current_date
    cPgCtr += 1

    file_output.write(f"Date:{current_date.strftime('%m/%d/%y'):<10}{'Basket Sales':^50}Page: {cPgCtr:<20}\n"
            f"{'----------------------':^80}\n"
            f"\tBasket Price\tQuantity\tSubtotal\tDiscount\tTotal\n")

    cLineCtr += 4


def read(file_input):
    global iBasketPrice, iQuantity, iDiscount, iCustomerName, iBasketType, iAccessories, moreRecs
    line = file_input.readline()
    if line:
        line = line.strip()

        iBasketPrice = float(line[:5])
        iQuantity = int(line[5:8])
        iDiscount = float(line[8:16])
        iCustomerName = line[16:26]
        iBasketType = line[26:34]
        iAccessories = line[34:42]
    else:
        moreRecs = "No"

def calcs():
    global cSubtotal, iBasketPrice, iQuantity, iDiscount, cTotal, cGtSubtotal, cGtDiscount, cGtTotal, cGtCustomerCtr, cGtQuantity

    cSubtotal = iBasketPrice * iQuantity
    cTotal = cSubtotal - iDiscount

    cGtCustomerCtr += 1
    cGtDiscount += iDiscount
    cGtQuantity += iQuantity
    cGtSubtotal += cSubtotal
    cGtTotal += cTotal


def output(file_output):
    global oBasketPrice, oQuantity, oSubtotal, oDiscount, oTotal, iBasketPrice, iQuantity, iDiscount, cSubtotal, cTotal, cLineCtr

    # right alignment, iBasketPrice will take 8 total spaces
    oBasketPrice = f"{iBasketPrice:>8,.2f}"
    oQuantity = f"{iQuantity:>12}"
    oSubtotal = f"{cSubtotal:>12,.2f}"
    oDiscount = f"{iDiscount:>12,.2f}"
    oTotal = f"{cTotal:>9,.2f}"

    file_output.write(f"\t\t{oBasketPrice}{oQuantity}{oSubtotal}{oDiscount}{oTotal}\n")

    cLineCtr += 1

    if cLineCtr >= 60:
        cLineCtr = 0
        headings(file_output)

def grandtotals(file_output):
    global cGtCustomerCtr, cGtDiscount, cGtQuantity, cGtSubtotal, cGtTotal, oGtCustomerCtr, oGtDiscount, oGtQuantity, oGtSubtotal, oGtTotal

    oGtCustomerCtr = f"{cGtCustomerCtr}"
    oGtDiscount = f"{cGtDiscount:.2f}"
    oGtQuantity = f"{cGtQuantity}"
    oGtSubtotal = f"{cGtSubtotal:.2f}"
    oGtTotal = f"{cGtTotal:.2f}"

    file_output.write(f"\n\n\nCustomer Counter: {oGtCustomerCtr:>3}\n"
                      f"Discount: {oGtDiscount:>11}\n"
                      f"Quantity: {oGtQuantity:>11}\n"
                      f"Subtotal: {oGtSubtotal:>11}\n"
                      f"Total: {oGtTotal:>14}\n")

def closing(file_output, file_input):
    file_output.close()
    file_input.close()

main()
